
import React, { useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send } from 'lucide-react';

const Chatbot = () => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = () => {
    if (inputValue.trim() === '') return;

    const userMessage = { sender: 'user', text: inputValue };
    // Placeholder for bot response - requires Bhashini integration
    const botMessage = { sender: 'bot', text: t('chatbot_placeholder_response') };

    setMessages([...messages, userMessage, botMessage]);
    setInputValue('');

    // TODO: Add Bhashini API call here for actual bot response
    console.warn("Bhashini API call needed for chatbot response.");
  };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-gray-800 border-gray-700 flex flex-col h-[70vh]">
      <CardHeader>
        <CardTitle className="text-white">{t('chatbot_title')}</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-full p-4 space-y-4">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[75%] rounded-lg px-4 py-2 ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-600 text-white'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
           {messages.length === 0 && (
             <p className="text-center text-gray-400">{t('chatbot_welcome')}</p>
           )}
        </ScrollArea>
      </CardContent>
      <CardFooter className="p-4 border-t border-gray-700">
        <div className="flex w-full items-center space-x-2">
          <Input
            type="text"
            placeholder={t('chatbot_input_placeholder')}
            value={inputValue}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
          />
          <Button type="submit" size="icon" onClick={handleSendMessage} className="bg-blue-600 hover:bg-blue-700">
            <Send className="h-4 w-4" />
            <span className="sr-only">{t('chatbot_send_button')}</span>
          </Button>
        </div>
         <p className="text-xs text-gray-500 mt-2">{t('bhashini_api_notice')}</p>
      </CardFooter>
    </Card>
  );
};

export default Chatbot;
