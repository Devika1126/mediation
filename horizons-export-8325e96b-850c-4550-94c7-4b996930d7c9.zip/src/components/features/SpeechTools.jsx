
import React, { useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Mic, Volume2, Play, Pause } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const SpeechTools = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [textToSpeak, setTextToSpeak] = useState('');
  const [recognizedText, setRecognizedText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleStartRecording = () => {
    // Placeholder for Bhashini Speech-to-Text START
    setIsRecording(true);
    setRecognizedText(t('speech_recording_placeholder')); // Placeholder text
    console.warn("Bhashini API call needed to START speech recognition.");
    toast({ title: t('speech_recording_started') });

    // Simulate recording stop after a few seconds for demo
    setTimeout(handleStopRecording, 4000);
  };

  const handleStopRecording = () => {
    // Placeholder for Bhashini Speech-to-Text STOP and get result
    setIsRecording(false);
    setRecognizedText(t('speech_recognition_placeholder_result')); // Placeholder result
    console.warn("Bhashini API call needed to STOP speech recognition and get result.");
     toast({ title: t('speech_recording_stopped') });
  };

  const handlePlaySpeech = () => {
     if (!textToSpeak.trim()) {
        toast({ title: t('speech_tts_empty_error'), variant: "destructive" });
        return;
     }
    // Placeholder for Bhashini Text-to-Speech PLAY
    setIsPlaying(true);
    console.warn("Bhashini API call needed to PLAY text-to-speech.");
    toast({ title: t('speech_tts_playing') });

    // Simulate playback stop after a few seconds for demo
    setTimeout(handleStopSpeech, 3000);
  };

   const handleStopSpeech = () => {
    // Placeholder for Bhashini Text-to-Speech STOP
    setIsPlaying(false);
    console.warn("Bhashini API call/audio control needed to STOP text-to-speech.");
     toast({ title: t('speech_tts_stopped') });
  };


  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white flex items-center">
         <Mic className="mr-2 h-6 w-6 text-red-400"/> {t('speech_tools_title')}
      </h1>
      <p className="text-gray-400">{t('speech_tools_subtitle')}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Speech to Text Card */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
               <Mic className="mr-2 h-5 w-5"/> {t('speech_stt_title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={isRecording ? handleStopRecording : handleStartRecording}
              className={`w-full ${isRecording ? 'bg-red-600 hover:bg-red-700' : 'btn-primary'}`}
            >
              <Mic className="mr-2 h-4 w-4" />
              {isRecording ? t('speech_stop_recording_button') : t('speech_start_recording_button')}
            </Button>
            <Textarea
              placeholder={t('speech_stt_placeholder')}
              value={recognizedText}
              readOnly={isRecording} // Make read-only while recording simulation is active
              onChange={(e) => !isRecording && setRecognizedText(e.target.value)} // Allow editing if needed, but primarily display recognized text
              className="bg-gray-700 border-gray-600 text-white min-h-[150px]"
            />
          </CardContent>
           <CardFooter>
                <p className="text-xs text-gray-500">{t('speech_stt_notice')}</p>
           </CardFooter>
        </Card>

        {/* Text to Speech Card */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
               <Volume2 className="mr-2 h-5 w-5"/> {t('speech_tts_title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
             <Textarea
              placeholder={t('speech_tts_placeholder')}
              value={textToSpeak}
              onChange={(e) => setTextToSpeak(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white min-h-[150px]"
            />
             <Button
                onClick={isPlaying ? handleStopSpeech : handlePlaySpeech}
                disabled={!textToSpeak.trim()}
                className={`w-full ${isPlaying ? 'bg-yellow-600 hover:bg-yellow-700' : 'btn-secondary'}`}
             >
                {isPlaying ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
                {isPlaying ? t('speech_tts_stop_button') : t('speech_tts_play_button')}
             </Button>
          </CardContent>
           <CardFooter>
                <p className="text-xs text-gray-500">{t('speech_tts_notice')}</p>
           </CardFooter>
        </Card>
      </div>
       <p className="text-xs text-gray-500 mt-2">{t('bhashini_api_notice')}</p>
    </div>
  );
};

export default SpeechTools;
