
import React from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mic, HelpCircle } from 'lucide-react';

const VirtualAssistant = () => {
  const { t } = useTranslation();

  const handleVoiceCommand = () => {
    // Placeholder for Bhashini Speech-to-Text integration
    console.warn("Bhashini API call needed for voice command processing.");
    alert(t('va_voice_placeholder_alert'));
  };

  const handleGetHelp = () => {
     alert(t('va_help_placeholder_alert'));
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">{t('va_title')}</h1>
      <p className="text-gray-400">{t('va_subtitle')}</p>

      <Card className="bg-gray-800 border-gray-700 text-center">
        <CardHeader>
          <CardTitle className="text-white">{t('va_card_title')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-4 p-8">
           <Mic className="h-16 w-16 text-blue-400 mb-4" />
          <p className="text-gray-300">{t('va_instruction')}</p>
          <Button onClick={handleVoiceCommand} className="btn-primary px-6 py-3">
            <Mic className="mr-2 h-5 w-5" />
            {t('va_start_button')}
          </Button>
           <Button onClick={handleGetHelp} variant="link" className="text-gray-400 hover:text-white">
             <HelpCircle className="mr-1 h-4 w-4" /> {t('va_help_button')}
           </Button>
        </CardContent>
      </Card>
       <p className="text-xs text-gray-500 mt-2">{t('bhashini_api_notice')}</p>
    </div>
  );
};

export default VirtualAssistant;
