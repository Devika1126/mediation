
import React, { useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Lightbulb, HelpCircle, BookText } from 'lucide-react';

// Placeholder Quiz Component
const Quiz = () => {
    const { t } = useTranslation();
    const [score, setScore] = useState(null);
    const questions = [ { q: t('quiz_q1'), a: 'A' }, { q: t('quiz_q2'), a: 'C' } ]; // Example

    const handleSubmit = (event) => {
        event.preventDefault();
        // Basic scoring logic placeholder
        setScore(Math.floor(Math.random() * questions.length) + 1); // Random score for demo
         alert(`${t('quiz_result_alert')} ${score || 0}/${questions.length}`);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <p>{questions[0].q}</p>
            {/* Add radio buttons/options here */}
             <div className="text-xs text-gray-400">{t('quiz_options_placeholder')}</div>
            <Button type="submit" className="btn-secondary">{t('quiz_submit_button')}</Button>
            {score !== null && <p>{t('quiz_your_score')}: {score}/{questions.length}</p>}
        </form>
    );
};

// Placeholder Simulation Component
const Simulation = () => {
    const { t } = useTranslation();
    return (
        <div className="space-y-4 text-center">
            <p>{t('simulation_desc')}</p>
             <img 
                className="w-full h-auto max-h-48 object-contain rounded-md filter grayscale"
                alt="Simulation graphic"
              src="https://images.unsplash.com/photo-1691878631216-91cd0a352e12" />
            <Button className="btn-secondary">{t('simulation_start_button')}</Button>
        </div>
    );
};

// Placeholder Storytelling Component
const Storytelling = () => {
     const { t } = useTranslation();
     return (
        <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t('story_title_placeholder')}</h3>
            <p>{t('story_content_placeholder')}</p>
            <Button variant="link" className="text-blue-400 hover:text-blue-300">{t('story_read_more')}</Button>
        </div>
     );
}


const InteractiveLearning = () => {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white flex items-center">
         <Lightbulb className="mr-2 h-6 w-6 text-yellow-400"/> {t('learning_title')}
      </h1>
      <p className="text-gray-400">{t('learning_subtitle')}</p>

      <Tabs defaultValue="quiz" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-700">
          <TabsTrigger value="quiz" className="data-[state=active]:bg-gray-900 data-[state=active]:text-white text-gray-300">
             <HelpCircle className="mr-2 h-4 w-4"/> {t('learning_tab_quiz')}
          </TabsTrigger>
          <TabsTrigger value="simulation" className="data-[state=active]:bg-gray-900 data-[state=active]:text-white text-gray-300">
             <Lightbulb className="mr-2 h-4 w-4"/> {t('learning_tab_simulation')}
          </TabsTrigger>
          <TabsTrigger value="storytelling" className="data-[state=active]:bg-gray-900 data-[state=active]:text-white text-gray-300">
             <BookText className="mr-2 h-4 w-4"/> {t('learning_tab_storytelling')}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="quiz">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">{t('learning_quiz_title')}</CardTitle>
            </CardHeader>
            <CardContent>
              <Quiz />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="simulation">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">{t('learning_simulation_title')}</CardTitle>
            </CardHeader>
            <CardContent>
              <Simulation />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="storytelling">
           <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">{t('learning_story_title')}</CardTitle>
            </CardHeader>
            <CardContent>
              <Storytelling />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
       <p className="text-xs text-gray-500 mt-2">{t('placeholder_content_notice')}</p>
    </div>
  );
};

export default InteractiveLearning;
