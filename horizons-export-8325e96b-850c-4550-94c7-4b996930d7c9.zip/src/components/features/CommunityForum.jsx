
import React, { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, MessageSquare } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CommunityForum = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [posts, setPosts] = useState([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Load posts from localStorage on mount
  useEffect(() => {
    const storedPosts = localStorage.getItem('forumPosts');
    if (storedPosts) {
      setPosts(JSON.parse(storedPosts));
    } else {
        // Add default placeholder post
        const defaultPosts = [
            { id: 1, author: "Admin", authorInitials: "AD", content: t('forum_welcome_post'), timestamp: new Date().toISOString() }
        ];
        setPosts(defaultPosts);
        localStorage.setItem('forumPosts', JSON.stringify(defaultPosts));
    }
  }, [t]); // Add t dependency to reload default post if language changes

  const handlePostSubmit = () => {
    if (newPostContent.trim() === '') {
      toast({ title: t('forum_empty_post_error'), variant: "destructive" });
      return;
    }
    setIsLoading(true);

    const newPost = {
      id: Date.now(), // Simple ID generation
      author: "CurrentUser", // Placeholder - needs actual user info
      authorInitials: "CU", // Placeholder
      content: newPostContent,
      timestamp: new Date().toISOString(),
    };

    // Simulate saving
    setTimeout(() => {
      const updatedPosts = [newPost, ...posts];
      setPosts(updatedPosts);
      localStorage.setItem('forumPosts', JSON.stringify(updatedPosts)); // Save to localStorage
      setNewPostContent('');
      setIsLoading(false);
      toast({ title: t('forum_post_success') });
      console.info("For a persistent and multi-user forum, consider migrating data to Supabase.");
    }, 500);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white flex items-center">
         <MessageSquare className="mr-2 h-6 w-6 text-green-400"/> {t('forum_title')}
      </h1>
      <p className="text-gray-400">{t('forum_subtitle')}</p>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t('forum_new_post_title')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder={t('forum_textarea_placeholder')}
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)}
            className="bg-gray-700 border-gray-600 text-white min-h-[100px]"
          />
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handlePostSubmit} disabled={isLoading} className="btn-primary">
            <Send className="mr-2 h-4 w-4" />
            {isLoading ? t('posting_button') : t('forum_post_button')}
          </Button>
        </CardFooter>
      </Card>

      <h2 className="text-2xl font-semibold text-white pt-4 border-t border-gray-700">{t('forum_recent_posts_title')}</h2>
      <div className="space-y-4">
        {posts.length > 0 ? (
          posts.map((post) => (
            <Card key={post.id} className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center space-x-4 pb-2">
                <Avatar>
                  {/* Placeholder for Avatar Image */}
                  {/* <AvatarImage src="/path/to/avatar.jpg" alt={post.author} /> */}
                  <AvatarFallback>{post.authorInitials}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-sm font-medium text-white">{post.author}</CardTitle>
                  <p className="text-xs text-gray-500">
                    {new Date(post.timestamp).toLocaleString()}
                  </p>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 whitespace-pre-wrap">{post.content}</p>
              </CardContent>
              {/* Add reply/like buttons here if needed */}
            </Card>
          ))
        ) : (
          <p className="text-gray-400">{t('forum_no_posts')}</p>
        )}
      </div>
       <p className="text-xs text-gray-500 mt-4">{t('localstorage_notice')}</p>
    </div>
  );
};

export default CommunityForum;
