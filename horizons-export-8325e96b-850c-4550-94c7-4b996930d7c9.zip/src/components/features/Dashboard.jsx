
import React from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { BarChart, Users, MessageSquare } from 'lucide-react';

const Dashboard = () => {
  const { t } = useTranslation();

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
      className="space-y-6"
    >
      <h1 className="text-3xl font-bold text-white">{t('dashboard_title')}</h1>
      <p className="text-gray-400">{t('dashboard_subtitle')}</p>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <motion.div variants={cardVariants}>
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">{t('dashboard_card1_title')}</CardTitle>
              <BarChart className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{t('dashboard_card1_value')}</div>
              <p className="text-xs text-gray-400">{t('dashboard_card1_desc')}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants}>
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">{t('dashboard_card2_title')}</CardTitle>
              <Users className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{t('dashboard_card2_value')}</div>
              <p className="text-xs text-gray-400">{t('dashboard_card2_desc')}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants}>
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">{t('dashboard_card3_title')}</CardTitle>
              <MessageSquare className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{t('dashboard_card3_value')}</div>
              <p className="text-xs text-gray-400">{t('dashboard_card3_desc')}</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

       <motion.div variants={cardVariants}>
         <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
                <CardTitle className="text-white">{t('welcome_title')}</CardTitle>
                 <CardDescription className="text-gray-400">{t('welcome_message')}</CardDescription>
            </CardHeader>
            <CardContent>
                 <img 
                    className="w-full h-auto max-h-60 object-cover rounded-md filter grayscale"
                    alt="Abstract representation of justice"
                  src="https://images.unsplash.com/photo-1591027265803-b51d1e644cb5" />
            </CardContent>
         </Card>
       </motion.div>

    </motion.div>
  );
};

export default Dashboard;
