
import React from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const InteractiveGuide = () => {
  const { t } = useTranslation();

  // Placeholder content - This would be more dynamic in a real implementation
  const steps = [
    { titleKey: 'guide_step1_title', descriptionKey: 'guide_step1_desc' },
    { titleKey: 'guide_step2_title', descriptionKey: 'guide_step2_desc' },
    { titleKey: 'guide_step3_title', descriptionKey: 'guide_step3_desc' },
  ];

  const [currentStep, setCurrentStep] = React.useState(0);

  const nextStep = () => {
    setCurrentStep((prev) => (prev + 1) % steps.length); // Loop back for demo
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">{t('guide_title')}</h1>
      <p className="text-gray-400">{t('guide_subtitle')}</p>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t(steps[currentStep].titleKey)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-300">{t(steps[currentStep].descriptionKey)}</p>
           <img 
              className="w-full h-auto max-h-48 object-cover rounded-md filter grayscale"
              alt="Illustration related to mediation step"
            src="https://images.unsplash.com/photo-1532619187608-e5375cab36aa" />
          <div className="flex justify-end">
            <Button onClick={nextStep} className="btn-primary">
              {t('guide_next_button')} <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
       <p className="text-xs text-gray-500 mt-2">{t('placeholder_content_notice')}</p>
    </div>
  );
};

export default InteractiveGuide;
