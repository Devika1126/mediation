
import React from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Info, AlertTriangle } from 'lucide-react';

const MediationFacts = () => {
  const { t } = useTranslation();

  // Placeholder static content
  const facts = [
    { id: 'fact1', titleKey: 'fact1_title', contentKey: 'fact1_content' },
    { id: 'fact2', titleKey: 'fact2_title', contentKey: 'fact2_content' },
    { id: 'fact3', titleKey: 'fact3_title', contentKey: 'fact3_content' },
  ];

  const myths = [
    { id: 'myth1', titleKey: 'myth1_title', contentKey: 'myth1_content' },
    { id: 'myth2', titleKey: 'myth2_title', contentKey: 'myth2_content' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
           <Info className="mr-2 h-6 w-6 text-blue-400"/> {t('facts_title')}
        </h1>
        <p className="text-gray-400">{t('facts_subtitle')}</p>
        <Accordion type="single" collapsible className="w-full mt-4">
          {facts.map((fact) => (
            <AccordionItem key={fact.id} value={fact.id} className="border-gray-700">
              <AccordionTrigger className="text-white hover:no-underline hover:text-blue-300">
                {t(fact.titleKey)}
              </AccordionTrigger>
              <AccordionContent className="text-gray-300">
                {t(fact.contentKey)}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
           <AlertTriangle className="mr-2 h-6 w-6 text-yellow-400"/> {t('myths_title')}
        </h1>
         <p className="text-gray-400">{t('myths_subtitle')}</p>
        <Accordion type="single" collapsible className="w-full mt-4">
          {myths.map((myth) => (
            <AccordionItem key={myth.id} value={myth.id} className="border-gray-700">
              <AccordionTrigger className="text-white hover:no-underline hover:text-yellow-300">
                {t(myth.titleKey)}
              </AccordionTrigger>
              <AccordionContent className="text-gray-300">
                {t(myth.contentKey)}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
};

export default MediationFacts;
