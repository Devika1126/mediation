
import React from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card'; // Added CardFooter
import { Button } from '@/components/ui/button';
import { Download, FileText } from 'lucide-react';

const OfflineResources = () => {
  const { t } = useTranslation();

  // Placeholder data - In reality, fetch this from a source (maybe Supabase Storage)
  const resources = [
    { id: 'res1', titleKey: 'offline_res1_title', descriptionKey: 'offline_res1_desc', fileUrl: '/placeholder/mediation_guide.pdf' },
    { id: 'res2', titleKey: 'offline_res2_title', descriptionKey: 'offline_res2_desc', fileUrl: '/placeholder/legal_terms.pdf' },
    { id: 'res3', titleKey: 'offline_res3_title', descriptionKey: 'offline_res3_desc', fileUrl: '/placeholder/adr_process.pdf' },
  ];

  const handleDownload = (url, title) => {
    // In a real app, this might trigger a download or open the file
    alert(`${t('downloading_alert')} ${title}`);
    console.warn(`Download functionality needs implementation for URL: ${url}`);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white flex items-center">
         <Download className="mr-2 h-6 w-6 text-purple-400"/> {t('offline_title')}
      </h1>
      <p className="text-gray-400">{t('offline_subtitle')}</p>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {resources.map((res) => (
          <Card key={res.id} className="bg-gray-800 border-gray-700 flex flex-col">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                 <FileText className="mr-2 h-5 w-5 text-gray-400"/> {t(res.titleKey)}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-gray-300 text-sm">{t(res.descriptionKey)}</p>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => handleDownload(res.fileUrl, t(res.titleKey))}
                variant="secondary"
                className="w-full btn-secondary"
              >
                <Download className="mr-2 h-4 w-4" />
                {t('download_button')}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
       <p className="text-xs text-gray-500 mt-2">{t('placeholder_content_notice')}</p>
    </div>
  );
};

export default OfflineResources;
