
import React, { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { MapPin, Star, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

// Placeholder for map component - requires library like Leaflet/React-Leaflet and OpenStreetMap
const MapPlaceholder = () => (
  <div className="h-64 w-full bg-gray-700 rounded-md flex items-center justify-center text-gray-400">
    {/* Replace with actual map component */}
    Map Placeholder (Requires OpenStreetMap Integration)
  </div>
);

const MediatorConnect = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [location, setLocation] = useState('');
  const [expertise, setExpertise] = useState('');
  const [mediators, setMediators] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load mediators from localStorage on mount
  useEffect(() => {
    const storedMediators = localStorage.getItem('mediators');
    if (storedMediators) {
      setMediators(JSON.parse(storedMediators));
    } else {
       // Add some default placeholder data if none exists
       const defaultMediators = [
         { id: 1, name: "Anya Sharma", location: "Delhi", expertise: "Family Law", rating: 4.5 },
         { id: 2, name: "Rohan Gupta", location: "Mumbai", expertise: "Commercial Disputes", rating: 4.8 },
         { id: 3, name: "Priya Singh", location: "Delhi", expertise: "Property Disputes", rating: 4.2 },
       ];
       setMediators(defaultMediators);
       localStorage.setItem('mediators', JSON.stringify(defaultMediators));
    }
  }, []);

  const handleSearch = () => {
    setIsLoading(true);
    // Placeholder for search logic - In reality, this would filter based on location/expertise
    // For now, just simulates a search and potentially filters the existing list
    console.warn("Search logic needs implementation. Using placeholder data.");

    // Basic filtering example (case-insensitive)
    const storedMediators = JSON.parse(localStorage.getItem('mediators') || '[]');
    const filtered = storedMediators.filter(m =>
        (location === '' || m.location.toLowerCase().includes(location.toLowerCase())) &&
        (expertise === '' || m.expertise.toLowerCase().includes(expertise.toLowerCase()))
    );

    setTimeout(() => {
        setMediators(filtered);
        setIsLoading(false);
        if (filtered.length === 0) {
             toast({ title: t('mediator_search_no_results_title'), description: t('mediator_search_no_results_desc'), variant: "destructive" });
        } else {
             toast({ title: t('mediator_search_success_title'), description: t('mediator_search_success_desc', { count: filtered.length }) });
        }
    }, 1000); // Simulate network delay

    // Suggest Supabase for real data
    console.info("For persistent and scalable mediator data, consider migrating to Supabase.");
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">{t('mediator_connect_title')}</h1>
      <p className="text-gray-400">{t('mediator_connect_subtitle')}</p>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t('mediator_search_title')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              type="text"
              placeholder={t('mediator_location_placeholder')}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Input
              type="text"
              placeholder={t('mediator_expertise_placeholder')}
              value={expertise}
              onChange={(e) => setExpertise(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Button onClick={handleSearch} disabled={isLoading} className="btn-primary md:col-span-1">
              <Search className="mr-2 h-4 w-4" />
              {isLoading ? t('searching_button') : t('search_button')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Map Placeholder */}
      <MapPlaceholder />

      <h2 className="text-2xl font-semibold text-white pt-4 border-t border-gray-700">{t('mediator_results_title')}</h2>
      {isLoading ? (
         <p className="text-gray-400">{t('loading_text')}</p>
      ) : mediators.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {mediators.map((mediator) => (
            <Card key={mediator.id} className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-colors">
              <CardHeader>
                <CardTitle className="text-white">{mediator.name}</CardTitle>
                <CardDescription className="text-gray-400 flex items-center">
                  <MapPin className="mr-1 h-4 w-4" /> {mediator.location}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-300 mb-2">{t('expertise_label')}: {mediator.expertise}</p>
                <div className="flex items-center text-yellow-400">
                  <Star className="mr-1 h-4 w-4 fill-current" /> {mediator.rating} / 5.0
                </div>
              </CardContent>
              {/* Add a connect button or contact info here */}
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-gray-400">{t('mediator_no_results_text')}</p>
      )}
       <p className="text-xs text-gray-500 mt-4">{t('localstorage_notice')}</p>
       <p className="text-xs text-gray-500">{t('map_integration_notice')}</p>
    </div>
  );
};

export default MediatorConnect;
