
import React, { useState, useCallback } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Upload, FileText, Languages } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const DocumentTranslator = () => {
  const { t, currentLanguage } = useTranslation();
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileContent, setFileContent] = useState('');
  const [translatedContent, setTranslatedContent] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);

  const handleFileChange = useCallback((event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      // Read file content (basic text reading, might need libraries for PDF/DOCX)
      const reader = new FileReader();
      reader.onload = (e) => {
        setFileContent(e.target.result);
        setTranslatedContent(''); // Clear previous translation
      };
      reader.onerror = () => {
         toast({ title: t('translator_file_read_error'), variant: "destructive" });
      }
      // For simplicity, assuming text files. Add checks for other types.
      if (file.type.startsWith('text/')) {
         reader.readAsText(file);
      } else {
          toast({ title: t('translator_unsupported_file_title'), description: t('translator_unsupported_file_desc'), variant: "destructive" });
          setSelectedFile(null);
          setFileContent('');
      }

    }
  }, [toast, t]);

  const handleTranslate = () => {
    if (!fileContent) {
       toast({ title: t('translator_no_content_error'), variant: "destructive" });
      return;
    }
    setIsTranslating(true);
    // Placeholder for Bhashini Translation API call
    console.warn("Bhashini API call needed for document translation.");
    setTimeout(() => {
      // Simulate translation - replace with actual API result
      setTranslatedContent(`${t('translator_placeholder_result')}\n\n${fileContent}`);
      setIsTranslating(false);
      toast({ title: t('translator_success_toast') });
    }, 1500); // Simulate network delay
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white flex items-center">
         <Languages className="mr-2 h-6 w-6 text-teal-400"/> {t('translator_title')}
      </h1>
      <p className="text-gray-400">{t('translator_subtitle')}</p>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t('translator_upload_title')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="document-upload" className="text-gray-300">{t('translator_select_label')}</Label>
            <Input
              id="document-upload"
              type="file"
              onChange={handleFileChange}
              accept=".txt,.pdf,.doc,.docx" // Adjust accepted types as needed
              className="bg-gray-700 border-gray-600 text-white file:text-gray-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gray-600 hover:file:bg-gray-500"
            />
             {selectedFile && <p className="text-sm text-gray-400 mt-2">{t('translator_selected_file')}: {selectedFile.name}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
                <Label className="text-gray-300">{t('translator_original_label')}</Label>
                <Textarea
                    value={fileContent}
                    readOnly
                    placeholder={t('translator_original_placeholder')}
                    className="bg-gray-700 border-gray-600 text-white min-h-[200px]"
                />
             </div>
             <div>
                 <Label className="text-gray-300">{t('translator_translated_label')} ({t(`language_name_${currentLanguage}`)})</Label>
                 <Textarea
                    value={translatedContent}
                    readOnly
                    placeholder={t('translator_translated_placeholder')}
                    className="bg-gray-700 border-gray-600 text-white min-h-[200px]"
                />
             </div>
          </div>

        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleTranslate} disabled={!fileContent || isTranslating} className="btn-primary">
            <Languages className="mr-2 h-4 w-4" />
            {isTranslating ? t('translating_button') : t('translator_translate_button')}
          </Button>
        </CardFooter>
      </Card>
       <p className="text-xs text-gray-500 mt-2">{t('bhashini_api_notice')}</p>
       <p className="text-xs text-gray-500">{t('translator_file_support_notice')}</p>
    </div>
  );
};

export default DocumentTranslator;
