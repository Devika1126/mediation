
import React, { createContext, useState, useContext, useEffect } from 'react';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    // Initialize language from localStorage or default to null (prompt selection)
    return localStorage.getItem('preferredLanguage') || null;
  });

  // Effect to update localStorage when language changes
  useEffect(() => {
    if (language) {
      localStorage.setItem('preferredLanguage', language);
    } else {
      localStorage.removeItem('preferredLanguage');
    }
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
