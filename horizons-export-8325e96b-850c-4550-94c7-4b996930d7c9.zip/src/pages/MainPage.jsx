
import React from 'react';
import { Routes, Route, Link, useLocation, useNavigate, Navigate } from 'react-router-dom'; // Added Navigate
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from 'framer-motion'; // Added AnimatePresence
import { Home, MessageSquare, Bot, BookOpen, Users, Search, GraduationCap, Download, FileText, Mic, Volume2, Info } from 'lucide-react';

// Import feature components
import Dashboard from '@/components/features/Dashboard';
import Chatbot from '@/components/features/Chatbot';
import InteractiveGuide from '@/components/features/InteractiveGuide';
import VirtualAssistant from '@/components/features/VirtualAssistant';
import MediationFacts from '@/components/features/MediationFacts';
import MediatorConnect from '@/components/features/MediatorConnect';
import CommunityForum from '@/components/features/CommunityForum';
import InteractiveLearning from '@/components/features/InteractiveLearning';
import OfflineResources from '@/components/features/OfflineResources';
import DocumentTranslator from '@/components/features/DocumentTranslator';
import SpeechTools from '@/components/features/SpeechTools';

const MainPage = () => {
  const { setLanguage } = useLanguage();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  const handleChangeLanguage = () => {
    localStorage.removeItem('preferredLanguage');
    setLanguage(null);
    navigate('/language');
  };

  // Determine the active tab based on the current path
  const getActiveTab = () => {
    // Match the path segment after the first slash
    const pathSegments = location.pathname.split('/').filter(Boolean);
    return pathSegments[0] || 'dashboard'; // Default to dashboard if no segment
  };


  const features = [
    { id: 'dashboard', labelKey: 'tab_dashboard', icon: Home, component: Dashboard },
    { id: 'chatbot', labelKey: 'tab_chatbot', icon: Bot, component: Chatbot },
    { id: 'guide', labelKey: 'tab_guide', icon: BookOpen, component: InteractiveGuide },
    { id: 'assistant', labelKey: 'tab_assistant', icon: MessageSquare, component: VirtualAssistant },
    { id: 'facts', labelKey: 'tab_facts', icon: Info, component: MediationFacts },
    { id: 'connect', labelKey: 'tab_connect', icon: Search, component: MediatorConnect },
    { id: 'forum', labelKey: 'tab_forum', icon: Users, component: CommunityForum },
    { id: 'learning', labelKey: 'tab_learning', icon: GraduationCap, component: InteractiveLearning },
    { id: 'offline', labelKey: 'tab_offline', icon: Download, component: OfflineResources },
    { id: 'translator', labelKey: 'tab_translator', icon: FileText, component: DocumentTranslator },
    { id: 'speech', labelKey: 'tab_speech', icon: Mic, component: SpeechTools }, // Combined STT/TTS
  ];

  return (
    <div className="flex h-screen bg-black text-white">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-gray-900 p-4 flex flex-col justify-between border-r border-gray-700">
        <div>
          <h1 className="text-2xl font-bold mb-8 text-center text-white">Mediatex</h1>
          <nav className="space-y-2">
            {features.map((feature) => (
              <Link
                key={feature.id}
                to={`/${feature.id}`} // Relative path within MainPage's scope
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150 ${
                  getActiveTab() === feature.id
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <feature.icon className="mr-3 h-5 w-5" />
                {t(feature.labelKey)}
              </Link>
            ))}
          </nav>
        </div>
        <Button onClick={handleChangeLanguage} variant="outline" className="w-full mt-4 btn-outline">
          {t('change_language_button')}
        </Button>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 md:p-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={getActiveTab()} // Key ensures animation runs on route change
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Routes>
              {features.map((feature) => (
                 // Use relative paths for nested routes
                 <Route key={feature.id} path={`/${feature.id}`} element={<feature.component />} />
              ))}
               {/* Default route within MainPage */}
               <Route index element={<Navigate to="/dashboard" replace />} />
               {/* Fallback route within MainPage */}
               <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};

export default MainPage;
