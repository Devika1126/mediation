
import React from 'react';
import { motion } from 'framer-motion';

const SplashScreen = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.5,
        delayChildren: 0.5,
      },
    },
    exit: {
      opacity: 0,
      transition: { duration: 0.5 }
    }
  };

  const imageVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: [0, 1, 0.5, 1], // Fade in, fade out slightly, fade back in
      scale: [0.8, 1, 0.95, 1],
      transition: {
        duration: 3, // Total duration for the image animation sequence
        times: [0, 0.3, 0.6, 1], // Timing for each step in the opacity/scale array
        ease: "easeInOut",
      },
    },
  };

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  // Note: The "random bars transition" is complex. This uses a fade/scale effect.
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-screen bg-black"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
    >
      <motion.div variants={imageVariants} className="mb-8">
        <img 
          className="h-64 w-64 object-contain filter invert"
          alt="Lady Justice silhouette"
         src="https://images.unsplash.com/photo-1590099543482-3b3d3083a474" />
      </motion.div>
      <motion.h1
        className="text-4xl md:text-5xl font-bold text-white text-center"
        variants={textVariants}
      >
        Mediatex
      </motion.h1>
      <motion.p
        className="text-xl md:text-2xl text-gray-300 mt-2"
        variants={textVariants}
        style={{ transitionDelay: '0.2s' }} // Delay slightly after title
      >
        Justice in Motion
      </motion.p>
    </motion.div>
  );
};

export default SplashScreen;
