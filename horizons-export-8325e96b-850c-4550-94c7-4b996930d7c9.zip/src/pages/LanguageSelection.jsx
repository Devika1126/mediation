
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

// List of 22 prominent Indian languages (as per 8th Schedule)
const languages = [
  { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  { code: 'brx', name: 'Bodo', nativeName: 'बर’' },
  { code: 'doi', name: 'Dogri', nativeName: 'डोगरी' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'ks', name: 'Kashmiri', nativeName: 'کٲشُر' },
  { code: 'kok', name: 'Konkani', nativeName: 'कोंकणी' },
  { code: 'mai', name: 'Maithili', nativeName: 'मैथिली' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'mni', name: 'Manipuri (Meitei)', nativeName: 'মৈতৈলোন্' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  { code: 'sa', name: 'Sanskrit', nativeName: 'संस्कृतम्' },
  { code: 'sat', name: 'Santali', nativeName: 'ᱥᱟᱱᱛᱟᱲᱤ' },
  { code: 'sd', name: 'Sindhi', nativeName: 'सिन्धी' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'ur', name: 'Urdu', nativeName: 'اُردُو' },
  // Adding English for default/fallback
  { code: 'en', name: 'English', nativeName: 'English' },
];

const LanguageSelection = () => {
  const { setLanguage } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLanguageSelect = (langCode, langName) => {
    setLanguage(langCode);
    localStorage.setItem('preferredLanguage', langCode); // Persist choice
    toast({
      title: "Language Set",
      description: `Language changed to ${langName}.`,
    });
    navigate('/main');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.05, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black p-8">
      <motion.h1
        className="text-3xl md:text-4xl font-bold text-white mb-8 text-center"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Choose Your Language / अपनी भाषा चुनें
      </motion.h1>
      <motion.div
        className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 max-w-4xl w-full"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {languages.map((lang) => (
          <motion.div key={lang.code} variants={itemVariants}>
            <Button
              variant="outline"
              className="w-full h-auto py-3 px-2 text-center border-gray-600 hover:bg-gray-800 focus:bg-gray-700 focus:ring-2 focus:ring-gray-500 transition-colors duration-200 flex flex-col items-center justify-center"
              onClick={() => handleLanguageSelect(lang.code, lang.name)}
            >
              <span className="text-lg font-medium text-white">{lang.nativeName}</span>
              <span className="text-xs text-gray-400 mt-1">{lang.name}</span>
            </Button>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default LanguageSelection;
