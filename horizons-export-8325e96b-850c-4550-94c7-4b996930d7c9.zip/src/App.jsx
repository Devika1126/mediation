
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';
import SplashScreen from '@/pages/SplashScreen';
import LanguageSelection from '@/pages/LanguageSelection';
import MainPage from '@/pages/MainPage';
import { Toaster } from '@/components/ui/toaster';

function AppContent() {
  const { language } = useLanguage();
  const [showSplash, setShowSplash] = React.useState(true);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 4000); // Splash screen duration
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence mode="wait">
      {showSplash ? (
        <motion.div
          key="splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <SplashScreen />
        </motion.div>
      ) : (
        <motion.div
          key="content"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="min-h-screen bg-black text-white"
        >
          <Routes>
            <Route path="/language" element={<LanguageSelection />} />
            {/* Render MainPage only if language is selected, otherwise redirect */}
            <Route
              path="/*" // Use /* to handle nested routes within MainPage
              element={language ? <MainPage /> : <Navigate to="/language" replace />}
            />
          </Routes>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function App() {
  return (
    <LanguageProvider>
      <Router>
        <AppContent />
        <Toaster />
      </Router>
    </LanguageProvider>
  );
}

export default App;
