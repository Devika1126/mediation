
import { useLanguage } from '@/contexts/LanguageContext';
import en from '@/locales/en.json';
import hi from '@/locales/hi.json';
// Import other language files as needed
// import bn from '@/locales/bn.json';
// import ta from '@/locales/ta.json';

const translations = {
  en,
  hi,
  // bn,
  // ta,
  // Add other imported languages here
};

export const useTranslation = () => {
  const { language } = useLanguage();
  const defaultLang = 'en'; // Fallback language

  const t = (key) => {
    const langToUse = language && translations[language] ? language : defaultLang;
    return translations[langToUse]?.[key] || key; // Return key if translation not found
  };

  return { t, currentLanguage: language || defaultLang };
};
